﻿namespace ILA_PROJEKT_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Willkommen beim Quiz");
            Console.WriteLine("Geben Sie Ihren Namen ein");

            string benutzername = Console.ReadLine();

            Console.WriteLine($"Hallo, {benutzername}! Lass uns mit dem Quiz beginnen.");

            Thread.Sleep(1000);

            Console.WriteLine();

            int punkte = 0;

            Dictionary<string, string> fragenUndAntworten = new Dictionary<string, string>();

            Dictionary<string, Dictionary<string, bool>> antworten = new Dictionary<string, Dictionary<string, bool>>();

            fragenUndAntworten.Add("Frage 1: Wie viele Einwohner hat die Schweiz?", "C");
            fragenUndAntworten.Add("Frage 2: Wer hat die Fussball WM 2022 gewonnen?", "C");
            fragenUndAntworten.Add("Frage 3: Wann wurde die Schweiz gegründet?", "A");
            fragenUndAntworten.Add("Frage 4: Wann wurden die Twin Towers zerstört?", "C");
            fragenUndAntworten.Add("Frage 5: Wann wurde Amerika entdeckt?", "B");

            Dictionary<string, bool> antwortenFrage1 = new Dictionary<string, bool>();
            antwortenFrage1.Add("A) 69'000", false);
            antwortenFrage1.Add("B) 7'000'000", false);
            antwortenFrage1.Add("C) ~9'000'000", true);

            antworten.Add("Frage 1: Wie viele Einwohner hat die Schweiz?", antwortenFrage1);

            Dictionary<string, bool> antwortenFrage2 = new Dictionary<string, bool>();
            antwortenFrage2.Add("A) Polen", false);
            antwortenFrage2.Add("B) Russland", false);
            antwortenFrage2.Add("C) Argentinen", true);

            antworten.Add("Frage 2: Wer hat die Fussball WM 2022 gewonnen?", antwortenFrage2);

            Dictionary<string, bool> antwortenFrage3 = new Dictionary<string, bool>();
            antwortenFrage3.Add("A) 1291", true);
            antwortenFrage3.Add("B) 1848", false);
            antwortenFrage3.Add("C) 1945", false);

            antworten.Add("Frage 3: Wann wurde die Schweiz gegründet?", antwortenFrage3);

            Dictionary<string, bool> antwortenFrage4 = new Dictionary<string, bool>();
            antwortenFrage4.Add("A) 1999", false);
            antwortenFrage4.Add("B) 2005", false);
            antwortenFrage4.Add("C) 2001", true);

            antworten.Add("Frage 4: Wann wurden die Twin Towers zerstört?", antwortenFrage4);

            Dictionary<string, bool> antwortenFrage5 = new Dictionary<string, bool>();
            antwortenFrage5.Add("A) 1493", false);
            antwortenFrage5.Add("B) 1492", true);
            antwortenFrage5.Add("C) 1776", false);

            antworten.Add("Frage 5: Wann wurde Amerika entdeckt?", antwortenFrage5);

            foreach (var kvp in fragenUndAntworten)
            {
                string frage = kvp.Key;
                string korrekteAntwort = kvp.Value;

                Console.WriteLine(frage);

                Dictionary<string, bool> antwortenZuFrage = antworten[frage];

                foreach (var antwort in antwortenZuFrage)
                {
                    Console.WriteLine(antwort.Key);
                }

                Console.Write("Geben Sie Ihre Antwort ein (A/B/C): ");
                string benutzerAntwort = Console.ReadLine().ToUpper();

                if (antwortenZuFrage.ContainsKey(benutzerAntwort) && antwortenZuFrage[benutzerAntwort])
                {
                    Console.WriteLine("Deine Antwort ist richtig!");
                    punkte++;
                }
                else if (korrekteAntwort == benutzerAntwort)
                {
                    Console.WriteLine("Deine Antwort ist richtig!");
                    punkte++;
                }
                else
                {
                    Console.WriteLine("Schade, deine Antwort ist falsch.");
                }

                Console.WriteLine($"Ihr aktueller Punktestand: {punkte}");
                Console.WriteLine();
            }

            Console.WriteLine("Quiz beendet. Vielen Dank fürs Mitmachen!");
        }
    }
}